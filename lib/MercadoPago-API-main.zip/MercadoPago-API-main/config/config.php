<?php
//information from https://www.mercadopago.com.br/developers/panel/credentials?id=1261619918742645
//Sua chave publica teste
define('SAND_KEY', '');
//Sua chave teste
define('SAND_TOKEN', '');
//Sua chave publica producao
define('PROD_KEY', '');
//Sua chave producao
define('PROD_TOKEN', '');

//Seus ID`s
define('CLI_ID', '');
define('CLI_SECRECT', '');
